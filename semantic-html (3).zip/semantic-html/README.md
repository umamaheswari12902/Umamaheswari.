# Semantic.html

A Pen created on CodePen.

Original URL: [https://codepen.io/Sanjeevi-kumar-M/pen/ogjRVKp](https://codepen.io/Sanjeevi-kumar-M/pen/ogjRVKp).

